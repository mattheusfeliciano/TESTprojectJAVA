export interface FoodData {
    id?: number,
    title: string,
    image: string,
    price: number
}